package com.cg.capcafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapCafeApplication.class, args);
	}

}
